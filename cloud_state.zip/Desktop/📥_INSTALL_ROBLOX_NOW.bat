@echo off
title TITAN ROBLOX 1-CLICK INSTALLER (v1.11 QUANTUM)
color 0b
echo ==============================================================================
echo       TITAN 1-CLICK ROBLOX INSTALLER & BYPASS ENGINE (AR / EN)
echo       Lead Architect: M11 Dev - Mohamed (https://github.com/M11-Developer)
echo       Clean Deployment Architecture - Zero 403 Forbidden S3 Error
echo ==============================================================================
echo.
echo [1/5] Removing corrupted registry locks and installer temp caches...
echo       ????? ?????? ??????? ???????? ?????? ????? ???????...
reg delete "HKCU\Software\ROBLOX Corporation" /f >nul 2>&1
reg delete "HKLM\Software\ROBLOX Corporation" /f >nul 2>&1
if exist "%TEMP%\Roblox" rmdir /s /q "%TEMP%\Roblox" >nul 2>&1
if exist "%LOCALAPPDATA%\Roblox\Downloads" rmdir /s /q "%LOCALAPPDATA%\Roblox\Downloads" >nul 2>&1
echo [2/5] Applying Anti-Cheat (dtrace bypass) and Audio pipeline...
echo       ???? ???? ???? ?????? ??? ????? ???????...
sc.exe config dtrace start=disabled >nul 2>&1
net stop dtrace >nul 2>&1
net start audiosrv >nul 2>&1
net start AudioEndpointBuilder >nul 2>&1
echo [3/5] Obtaining official Roblox Player 64-bit Installer (setup.rbxcdn.com)...
echo       ??? ???? ??????? ?????? ??????? ???? ????? ???????...
if exist "C:\TitanData\RobloxPlayerInstaller.exe" (
    copy /y "C:\TitanData\RobloxPlayerInstaller.exe" "%TEMP%\RobloxPlayerInstaller.exe" >nul 2>&1
)
if not exist "%TEMP%\RobloxPlayerInstaller.exe" (
    curl.exe -fsSL "https://setup.rbxcdn.com/RobloxPlayerInstaller.exe" -o "%TEMP%\RobloxPlayerInstaller.exe"
)
if not exist "%TEMP%\RobloxPlayerInstaller.exe" (
    powershell -NoProfile -Command "Invoke-WebRequest -Uri https://setup.rbxcdn.com/RobloxPlayerInstaller.exe -OutFile %TEMP%\RobloxPlayerInstaller.exe"
)
if not exist "%TEMP%\RobloxPlayerInstaller.exe" (
    powershell -NoProfile -Command "winget install --id Roblox.Roblox --silent --accept-package-agreements --accept-source-agreements"
)
echo [4/5] Pre-configuring Direct3D 11, 60 FPS Lock & DPI Compatibility...
echo       ??? ????? ????????? ???????? ???? ????????...
set "ROBLOX_SETTINGS=%LOCALAPPDATA%\Roblox\ClientSettings"
if not exist "%ROBLOX_SETTINGS%" mkdir "%ROBLOX_SETTINGS%" >nul 2>&1
(
echo {
echo   "FFlagDebugGraphicsDisableDirect3D11": "False",
echo   "FFlagDebugGraphicsPreferD3D11": "True",
echo   "FFlagDebugGraphicsPreferD3D11FL10": "True",
echo   "DFFlagDisableDPIScale": "True",
echo   "DFIntTaskSchedulerTargetFps": 60,
echo   "FFlagTaskSchedulerLimitTargetFpsTo240": "True",
echo   "FFlagDebugDisableDirect3D12": "True",
echo   "FFlagDebugDisableVulkan": "True"
echo }
) > "%ROBLOX_SETTINGS%\ClientAppSettings.json"
for /d %%D in ("%LOCALAPPDATA%\Roblox\Versions\*") do (
    if not exist "%%D\ClientSettings" mkdir "%%D\ClientSettings" >nul 2>&1
    copy /y "%ROBLOX_SETTINGS%\ClientAppSettings.json" "%%D\ClientSettings\ClientAppSettings.json" >nul 2>&1
)
for /r "%LOCALAPPDATA%\Roblox\Versions" %%F in (RobloxPlayerBeta.exe RobloxPlayerLauncher.exe) do (
    if exist "%%F" reg add "HKCU\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers" /v "%%F" /t REG_SZ /d "~ RUNASADMIN WIN8RTM HIGHDPIAWARE" /f >nul 2>&1
)
reg add "HKCU\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers" /v "%LOCALAPPDATA%\Roblox\Versions\*\RobloxPlayerBeta.exe" /t REG_SZ /d "~ RUNASADMIN WIN8RTM HIGHDPIAWARE" /f >nul 2>&1
echo [5/5] Launching official Roblox Player Installer...
echo       ??? ??????? ????...
start "" "%TEMP%\RobloxPlayerInstaller.exe"
echo.
echo ==============================================================================
echo [SUCCESS] Official Roblox Player installation started cleanly!
echo           ?? ????? ?????? ?????! ????? ???? ?????? ?????? ??????.
echo Once installed, click [??_LAUNCH_ROBLOX_PLAYER.bat] to play at 60 FPS!
echo ==============================================================================
pause
