@echo off
title TITAN ROBLOX 1-CLICK INSTALLER (v1.11 QUANTUM)
color 0b
echo ==============================================================================
echo       TITAN 1-CLICK ROBLOX INSTALLER & BYPASS ENGINE
echo       Lead Architect: M11 Dev - Mohamed (https://github.com/M11-Developer)
echo ==============================================================================
echo.
echo [1/4] Applying Anti-Cheat and Audio bypass...
sc.exe config dtrace start=disabled >nul 2>&1
net stop dtrace >nul 2>&1
net start audiosrv >nul 2>&1
net start AudioEndpointBuilder >nul 2>&1
echo [2/4] Downloading latest official Roblox Player Launcher...
powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://setup.rbxcdn.com/RobloxPlayerLauncher.exe' -OutFile '%TEMP%\RobloxPlayerLauncher.exe'"
if not exist "%TEMP%\RobloxPlayerLauncher.exe" powershell -NoProfile -Command "winget install --id Roblox.Roblox --silent --accept-package-agreements --accept-source-agreements"
echo [3/4] Configuring Direct3D 11 / WARP settings...
set "ROBLOX_SETTINGS=%LOCALAPPDATA%\Roblox\ClientSettings"
if not exist "%ROBLOX_SETTINGS%" mkdir "%ROBLOX_SETTINGS%" >nul 2>&1
(
echo {
echo   "FFlagDebugGraphicsDisableDirect3D11": "False",
echo   "FFlagDebugGraphicsPreferD3D11": "True",
echo   "FFlagDebugGraphicsPreferD3D11FL10": "True",
echo   "DFFlagDisableDPIScale": "True",
echo   "DFIntTaskSchedulerTargetFps": 60,
echo   "FFlagTaskSchedulerLimitTargetFpsTo240": "True",
echo   "FFlagDebugDisableDirect3D12": "True",
echo   "FFlagDebugDisableVulkan": "True"
echo }
) > "%ROBLOX_SETTINGS%\ClientAppSettings.json"
for /d %%D in ("%LOCALAPPDATA%\Roblox\Versions\*") do (
    if not exist "%%D\ClientSettings" mkdir "%%D\ClientSettings" >nul 2>&1
    copy /y "%ROBLOX_SETTINGS%\ClientAppSettings.json" "%%D\ClientSettings\ClientAppSettings.json" >nul 2>&1
)
for /r "%LOCALAPPDATA%\Roblox\Versions" %%F in (RobloxPlayerBeta.exe RobloxPlayerLauncher.exe) do (
    if exist "%%F" reg add "HKCU\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers" /v "%%F" /t REG_SZ /d "~ RUNASADMIN WIN8RTM HIGHDPIAWARE" /f >nul 2>&1
)
reg add "HKCU\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers" /v "%LOCALAPPDATA%\Roblox\Versions\*\RobloxPlayerBeta.exe" /t REG_SZ /d "~ RUNASADMIN WIN8RTM HIGHDPIAWARE" /f >nul 2>&1
echo [4/4] Launching Roblox Installer...
start "" "%TEMP%\RobloxPlayerLauncher.exe"
echo.
echo [SUCCESS] Roblox installation started! Launch it from Desktop once installed.
pause
