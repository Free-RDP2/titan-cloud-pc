@echo off
title TITAN MESA3D OPENGL 4.5 ACCELERATOR (16GB RAM Datacenter)
color 0e
echo ==============================================================================
echo       TITAN MESA3D OPENGL 4.5 ACCELERATOR - M11 QUANTUM
echo       Lead Architect: M11 Dev - Mohamed (https://github.com/M11-Developer)
echo ==============================================================================
echo.
echo [1/2] Configuring software OpenGL 4.5 & Vulkan environment variables...
setx MESA_GL_VERSION_OVERRIDE 4.5 >nul 2>&1
setx MESA_GLSL_VERSION_OVERRIDE 450 >nul 2>&1
setx GALLIUM_DRIVER llvmpipe >nul 2>&1
setx LIBGL_ALWAYS_SOFTWARE 1 >nul 2>&1
echo [2/2] Direct3D 11 WARP hardware acceleration active.
echo.
echo ==============================================================================
echo [SUCCESS] Mesa3D OpenGL accelerator active! Minecraft & 3D apps enabled.
echo ==============================================================================
pause
