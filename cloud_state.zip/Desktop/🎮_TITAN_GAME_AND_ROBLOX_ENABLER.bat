@echo off
title TITAN ROBLOX & 3D GAMES ENABLER (v1.11 QUANTUM BYPASS)
color 0a
echo ==============================================================================
echo       TITAN GAMING BYPASS ENGINE - M11 QUANTUM EDITION (v1.11)
echo       Lead Architect: M11 Dev - Mohamed (https://github.com/M11-Developer)
echo ==============================================================================
echo.
echo [1/5] Stopping kernel dtrace anti-cheat triggers...
sc.exe config dtrace start=disabled >nul 2>&1
net stop dtrace >nul 2>&1
net stop DiagTrack >nul 2>&1
net stop WerSvc >nul 2>&1
echo [2/5] Ensuring Windows Audio is active...
net start audiosrv >nul 2>&1
net start AudioEndpointBuilder >nul 2>&1
echo [3/5] Configuring Roblox Direct3D 11 / WARP bypass settings...
set "ROBLOX_SETTINGS=%LOCALAPPDATA%\Roblox\ClientSettings"
if not exist "%ROBLOX_SETTINGS%" mkdir "%ROBLOX_SETTINGS%" >nul 2>&1
(
echo {
echo   "FFlagDebugGraphicsDisableDirect3D11": "False",
echo   "FFlagDebugGraphicsPreferD3D11": "True",
echo   "FFlagDebugGraphicsPreferD3D11FL10": "True",
echo   "DFFlagDisableDPIScale": "True",
echo   "DFIntTaskSchedulerTargetFps": 60,
echo   "FFlagTaskSchedulerLimitTargetFpsTo240": "True",
echo   "FFlagDebugDisableDirect3D12": "True",
echo   "FFlagDebugDisableVulkan": "True"
echo }
) > "%ROBLOX_SETTINGS%\ClientAppSettings.json"
for /d %%D in ("%LOCALAPPDATA%\Roblox\Versions\*") do (
    if not exist "%%D\ClientSettings" mkdir "%%D\ClientSettings" >nul 2>&1
    copy /y "%ROBLOX_SETTINGS%\ClientAppSettings.json" "%%D\ClientSettings\ClientAppSettings.json" >nul 2>&1
)
echo [4/5] Applying Windows 8 Compatibility & DPI flags to Roblox Player...
reg add "HKCU\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers" /v "%LOCALAPPDATA%\Roblox\Versions\*\RobloxPlayerBeta.exe" /t REG_SZ /d "~ RUNASADMIN WIN8RTM HIGHDPIAWARE" /f >nul 2>&1
for /r "%LOCALAPPDATA%\Roblox\Versions" %%F in (RobloxPlayerBeta.exe RobloxPlayerLauncher.exe) do (
    if exist "%%F" reg add "HKCU\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers" /v "%%F" /t REG_SZ /d "~ RUNASADMIN WIN8RTM HIGHDPIAWARE" /f >nul 2>&1
)
echo [5/5] Flushing DirectX Shader Caches...
del /q /f /s "%LOCALAPPDATA%\D3DSCache\*" >nul 2>&1
echo.
echo ==============================================================================
echo [SUCCESS] Gaming bypass applied! You can now launch Roblox Player smoothly!
echo ==============================================================================
echo.
pause
