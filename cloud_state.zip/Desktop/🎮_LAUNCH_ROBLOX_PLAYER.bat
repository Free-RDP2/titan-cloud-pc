@echo off
setlocal EnableDelayedExpansion
title TITAN ROBLOX PLAYER LAUNCHER (60 FPS UNLOCKED)
color 0a
echo ==============================================================================
echo       TITAN ROBLOX DIRECT PLAYER - 60 FPS UNLOCKED (AR / EN)
echo       Lead Architect: M11 Dev - Mohamed (https://github.com/M11-Developer)
echo ==============================================================================
echo.
set "FOUND_ROBLOX="
for /r "%LOCALAPPDATA%\Roblox\Versions" %%F in (RobloxPlayerBeta.exe) do (
    if exist "%%F" (
        set "FOUND_ROBLOX=%%F"
        goto launch_it
    )
)
for /r "C:\Program Files (x86)\Roblox\Versions" %%F in (RobloxPlayerBeta.exe) do (
    if exist "%%F" (
        set "FOUND_ROBLOX=%%F"
        goto launch_it
    )
)
:launch_it
if defined FOUND_ROBLOX (
    echo [OK] Launching Roblox Player / ????? ?????? ????: "!FOUND_ROBLOX!"
    start "" "!FOUND_ROBLOX!"
    timeout /t 3 >nul
    exit /b 0
) else (
    echo [NOTICE] Roblox Player not found yet. Running 1-Click Installer...
    echo [?????] ?? ??? ?????? ??? ?????? ????? ???. ???? ????? ?????? ???????...
    call "%~dp0\??_INSTALL_ROBLOX_NOW.bat"
)
