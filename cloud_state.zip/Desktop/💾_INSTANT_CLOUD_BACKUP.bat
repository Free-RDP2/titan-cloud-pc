@echo off
title TITAN CLOUD SYNC - INSTANT DATA PRESERVATION
color 0a
echo ==============================================================================
echo       TITAN CLOUD WORKSTATION - INSTANT CONTINUOUS PRESERVATION
echo       Lead Architect: M11 Dev - Mohamed (https://github.com/M11-Developer)
echo ==============================================================================
echo.
echo [1/2] Packaging your Desktop, Documents, Downloads and App Settings...
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\TitanData\titan_persistent_daemon.ps1" -ForceNow
echo.
echo ==============================================================================
echo [SUCCESS] Your files and entire session are securely backed up in Cloud!
echo ==============================================================================
pause
